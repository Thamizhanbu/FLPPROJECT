package com.capgemini.flp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.exception.FeedbackException;
import com.capgemini.flp.service.IntService;



@Configuration
@Controller
@RequestMapping(value="/feedback")
public class CustomerController {
   @Autowired 
   IntService service;
   
 /*to display the form*/
   @RequestMapping(value="/forms")
   public ModelAndView getMenu(@ModelAttribute("feed") Feedback feedback, Map<String,List<Integer>> map)
   {
	    List<Integer> list1 = new ArrayList<>();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list1.add(5);
		map.put("rating",list1);
		Feedback feed=new Feedback();
		   return new ModelAndView("feedback","feed",feed);
   } 
   
   
   
	@RequestMapping(value="/fb",method=RequestMethod.POST)
	public ModelAndView getFeedbackPage(@ModelAttribute("feed") Feedback feedback)
	{
		try
		{
		System.out.println("hi");
		String result;
		boolean flag=service.getFeedbackPage(feedback);
		if(flag)
		{
			result="Your feedback is submittted. Thank you";
		}else
		{
			result="An error occurred try again";
		}
		
		return new ModelAndView("output","result",result);
		
	}catch(FeedbackException e)
		{
		return new ModelAndView("status","status",e.getMessage());
		}
	
}
}