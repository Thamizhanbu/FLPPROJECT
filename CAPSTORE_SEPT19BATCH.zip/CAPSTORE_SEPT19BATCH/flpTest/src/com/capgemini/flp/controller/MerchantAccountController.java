package com.capgemini.flp.controller;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.AllException;
import com.capgemini.flp.exception.MerchantException;
import com.capgemini.flp.service.IAdminService;
import com.capgemini.flp.service.IMerchantService;

@Controller
public class MerchantAccountController {

/*	@Autowired
	private IMerchantService service;
	
	@RequestMapping(value="/findall")
	public List<Merchant> findall() throws MerchantException{
		return service.findAllMerchants();
	}
	
	@RequestMapping(value="/addmerchant")
	public String addMerchant(@RequestBody String emailId) throws MerchantException {
		return service.addMerchant(emailId);
	}
	
	@RequestMapping(value="/removemerchant")
	public String removeMerchant(@RequestBody String emailId) throws MerchantException {
		return service.removeMerchant(emailId);
	}
	
	@RequestMapping(value="/invitemerchant")
	public String inviteMerchant(@RequestBody String emailId) throws MerchantException {
		return service.inviteMerchant(emailId);
	}*/
	@Autowired
	private IMerchantService service;
	
	@RequestMapping("/removemerchant")
	public ModelAndView removeMerchantProduct(@RequestParam(value="emailId") String emailId) {
		System.out.println(emailId);
		service.removeMerchantProducts(emailId);
		
		return new ModelAndView("success","success","removed");
		
	}
}