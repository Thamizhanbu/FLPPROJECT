package com.capgemini.flp.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.MerchantProductException;
import com.capgemini.flp.service.IMerchantProductService;

@Controller
public class MerchantController {
	
	@Autowired
	IMerchantProductService service;
	


	@RequestMapping("/addProduct")
	public ModelAndView showAdd() {
	
		return new ModelAndView("add","product", new Merchant_Product());
	}
	

	@RequestMapping("/add")
	public ModelAndView addMerchantProduct( @ModelAttribute(value="product") Merchant_Product product) {
	
	        boolean flag;
			flag=service.addMerchantProducts(product);
			String result;
			if(flag)
			{
				result="Your details are added";
				
			}else
			{
			result="An error occurred";
			}
			return new ModelAndView("message","message",result);
	}
	
	@RequestMapping("/remove")
	public ModelAndView removeMerchantProduct(@RequestParam(value="productId") int productId) {
		System.out.println(productId);
		service.removeMerchantProducts(productId);
		
		return new ModelAndView("success","success","res");
		
	}

	
}




	