package com.capgemini.flp.controller;

/*import org.springframework.beans.factory.annotation.Autowired();*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.service.ProductServiceInterface;



@Configuration
@Controller
public class Product {
	
@Autowired
ProductServiceInterface productservice;


@RequestMapping(value="/")
public String getIndexPage() {
	
	return "index";
}

@RequestMapping(value="/promo")
public String dataDisplay() {
	return "promopage";
}	

	@RequestMapping(value="/prod")
	public ModelAndView details(@RequestParam(value="promocode")String promo) {
		
		Merchant_Product m=productservice.details(promo);
		
		return new ModelAndView("Discountpromo", "m", m);
	}
	
	@RequestMapping(value="/apply")
	public ModelAndView discount(@RequestParam(value="userid")Integer userid)
	{
          String result;
		boolean b=productservice.discountUpdation(userid);
		if(b)
		{
			result="Your Discount amount got reduced  Successfully from the actual amount";
		}
		else
		{
			result="Unsuccessfull";
		}
          return new ModelAndView("Success5","result",result);
	}
	
	
}
	


