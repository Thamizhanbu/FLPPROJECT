package com.capgemini.flp.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.IMerchantProfileException;
import com.capgemini.flp.service.IProfileService;

@Controller
public class ProfileController {
	
	@Autowired
	IProfileService productService;
	
	@RequestMapping(value="/custpage", method=RequestMethod.GET)
	public ModelAndView customerHomePage(@RequestParam(value="emailId") String emailId) {
		Customer customer=new Customer();
		customer.setEmailId(emailId);
			return new ModelAndView("custhomepage","customer",customer);
	} 
	
	
	@RequestMapping(value="/cpage", method=RequestMethod.GET)
	public ModelAndView customerPage(@RequestParam(value="emailId") String emailId) {
		Customer customer=new Customer();
		customer.setEmailId(emailId);
			return new ModelAndView("CustomerPage","customer",customer);
	} 
	
	@RequestMapping(value="/mpage", method=RequestMethod.GET)
	public ModelAndView MerchantPage(@RequestParam(value="emailId") String emailId) {
		Merchant merchant= new Merchant();
		merchant.setEmailId(emailId);
			return new ModelAndView("MerchantPage","merchant",merchant);
	} 
	
	
	
	@RequestMapping(value="/cprofile", method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Customer customer=new Customer();
			return new ModelAndView("CustomerProfile","customer",customer);
	} 
	
	@RequestMapping(value="/mprofile", method=RequestMethod.GET)
	public ModelAndView merchantForm(@RequestParam(value="emailId") String emailId) {
		Merchant merchant= new Merchant();
		merchant.setEmailId(emailId);
			return new ModelAndView("MerchantProfile","merchant",merchant);
	} 
	
	@RequestMapping(value="/editp", method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute(value="customer")Customer c){
		try{
			String status=productService.updateCustomer(c);
			return new ModelAndView("Status","message",status);
		}catch(IMerchantProfileException e){
			return new ModelAndView("Status","message",e.getMessage());
		}
	}

	@RequestMapping(value="/editm", method=RequestMethod.POST)
	public ModelAndView updateMerchant(@ModelAttribute(value="merchant")Merchant m, @RequestParam(value="emailId") String emailId){
		try{
			String status=productService.updateMerchant(m,emailId);
			return new ModelAndView("Status1","message",status);
		}catch(IMerchantProfileException e){
			return new ModelAndView("Status1","message",e.getMessage());
		}
	}
	
}
