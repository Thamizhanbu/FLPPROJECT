package com.capgemini.flp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.model.Revenue;
import com.capgemini.flp.service.IRevenueService;

@Controller
public class RevenueController {
	@Autowired
	IRevenueService service;
 
	
	@RequestMapping(value="/revenuepage")
	public ModelAndView answer(@RequestParam("emailId") String email) {
	Merchant_Product mail= service.findProductSold(email);
	System.out.println("revenue");
	return new ModelAndView("revenuesuccess","list",mail);
	}
	

	@RequestMapping(value="/totalamount")
	public ModelAndView total(@RequestParam("email") String email) {
	Revenue rev= (Revenue) service.findRevenue(email);
	return new ModelAndView("revenuedetails","amount",rev);
		
}
	
	
	}
	

