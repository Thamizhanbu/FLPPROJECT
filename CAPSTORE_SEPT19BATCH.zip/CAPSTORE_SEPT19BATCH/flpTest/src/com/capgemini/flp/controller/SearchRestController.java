package com.capgemini.flp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.service.SearchServiceInterface;
@Configuration
@Controller
public class SearchRestController {
	
	@Autowired
	SearchServiceInterface service;
	
	
	
		
	@RequestMapping("/findCustomer")
	public ModelAndView findCustomer(@RequestParam String customerName)
	{
		
		System.out.println("in controller");
		System.out.println(customerName);
		List<Customer> customerList = new ArrayList<Customer>();
		customerList = (List<Customer>) service.findCustomerByName(customerName);
		for (Customer customerEntity : customerList) {
			System.out.println(customerEntity);

		}
		return new ModelAndView("showcustomers","customerlist",customerList);
		
	}
	

	@RequestMapping(value="/findMerchant")
	public ModelAndView findMerchantByName(@RequestParam String merchantName)
	{
		List<Merchant> merchantlist = new ArrayList<Merchant>();
		merchantlist = (List<Merchant>) service.findMerchantByName(merchantName);
		for (Merchant merchantEntity : merchantlist) {
			System.out.println(merchantEntity);

		}
		return new ModelAndView("showmerchants","merchantlist",merchantlist);
		
	}
	
	
	@RequestMapping(value="/findAllProducts")
	public ModelAndView findAllProducts(@RequestParam String merchantName)
	{
		List<Merchant_Product> productsList = new ArrayList<Merchant_Product>();
		productsList = (List<Merchant_Product>) service.findAllProducts(merchantName);
		for (Merchant_Product productEntity : productsList) {
			System.out.println(productEntity);

		}
		return new ModelAndView("show","productslist",productsList);
		
	}
	
	
	@RequestMapping(value="/findProducts")
	public ModelAndView findProducts(@RequestParam String productName)
	{
		System.out.println("in find products");
		List<Merchant_Product> productsList = new ArrayList<Merchant_Product>();
		productsList = (List<Merchant_Product>) service.findProducts(productName);
		for (Merchant_Product productEntity : productsList) {
			System.out.println(productEntity);

		}
		return new ModelAndView("showproducts","productslist",productsList);
		
	}
	
	
	

}
