package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.dto.Order;
import com.capgemini.flp.dto.User;

@Repository
@Transactional
public class DaoImpl implements IDaoPay{
	
	@PersistenceContext
	@Autowired
	EntityManager entityManager;
	
	@Override
	public String create(User user) {
	entityManager.persist(user);
	return "success";
	}

	//@Override
	/*public Order updateOrder(int orderId, int productId) {
		
			Order order=new Order(); 
			Admin admins=entityManager.find(Admin.class,productId);
			order.setProductId(admins.getProductId());
			order.setProductName(admins.getProductName());
			order.setProductPrice(admins.getProductPrice());
			order.setProduct_image(admins.getProductImage());
			order.setProductQuantity(admins.getProductQuantity());
			
			System.out.println(order.getProductId());
			
			entityManager.merge(order);
			return order;
		}*/

	@Override
	public String update(int proid) {
		String status=""; 
		/*TypedQuery<Admin> query=entityManager.createQuery("select a from admin_product a where a.order_Id=?",Admin.class);
		query.setParameter(1,orderid); 
		List<Admin> list=query.getResultList();
		System.out.println(list);*/
		Order od= new Order();
		Merchant_Product ad=entityManager.find(Merchant_Product.class, proid);
		if(ad!= null){
			od.setProductId(ad.getProductId());
			od.setProductName(ad.getProductName());
			od.setProductPrice(ad.getProductPrice());
			od.setProduct_image(ad.getProductImage());
			od.setProductQuantity(ad.getProductQuantity());
			entityManager.persist(od);
			status="Order table updated";
		}else{
			status="Product not Found";
		}
		
		return status;			
	}
		 
	}


