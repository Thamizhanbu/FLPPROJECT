package com.capgemini.flp.dao;

import com.capgemini.flp.dto.Delivery;
import com.capgemini.flp.exception.CustomerException;

public interface IDAODelivery {
/*	ArrayList<Delivery> getStatus() throws CustomerException ;*/
	Delivery getStatus(Integer productId) throws CustomerException;
	Delivery add(Integer productId,Delivery delivery);
}
