package com.capgemini.flp.dao;

import com.capgemini.flp.dto.User;

public interface IDaoPay {

	public String create(User user);
	
//	public Order updateOrder(int orderId, int productId);


	public String update(int orderid);
}
