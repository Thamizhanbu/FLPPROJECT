package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.MerchantProductException;

public interface IMerchantProductDao {
	
	public boolean addMerchantProducts(Merchant_Product product) ;

	public void removeMerchantProducts(int productId);

}
