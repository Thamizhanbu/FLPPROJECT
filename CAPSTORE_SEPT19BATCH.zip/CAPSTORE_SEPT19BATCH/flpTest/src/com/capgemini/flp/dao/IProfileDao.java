package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.IMerchantProfileException;

public interface IProfileDao {
	
	public List<Admin> getProducts() throws IMerchantProfileException;
	
	public List<Admin> getProductsBasedOnCategory(String name) throws IMerchantProfileException;

	public String updateCustomer(Customer c)throws IMerchantProfileException;

	public String updateMerchant(Merchant m,String emailId) throws IMerchantProfileException;

}
