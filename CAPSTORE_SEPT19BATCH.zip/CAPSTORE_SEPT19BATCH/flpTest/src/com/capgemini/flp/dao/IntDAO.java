package com.capgemini.flp.dao;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.exception.FeedbackException;

public interface IntDAO {

	public boolean getFeedbackPage(Feedback feedback)throws FeedbackException;
	

}
