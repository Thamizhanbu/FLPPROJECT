package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;



import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.MerchantProductException;


@Repository
public class MerchantProductDaoImpl implements IMerchantProductDao{
    
	@PersistenceContext
	EntityManager em;
	

	
	@Override
	public boolean addMerchantProducts(Merchant_Product product){
		

		em.persist(product);
		return true;
	}
	
	
	@Override
	public void removeMerchantProducts(int productId) {
		// TODO Auto-generated method stub
		Merchant_Product product =em.find(Merchant_Product.class,productId);
		em.remove(product);
		
	}

	
	
 }
