package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/*import org.springframework.beans.factory.annotation.Autowired;*/
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;

@Configuration
@Repository
public class ProductDaoImplementation implements ProductDaoInterface{


	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public Merchant_Product details(String promo) {
		Merchant_Product merchant=new Merchant_Product();
		double d;
		String rs1="select m from Merchant m where m.product_Id=?1";
		TypedQuery<Merchant_Product> query = em.createQuery(rs1, Merchant_Product.class);
		query.setParameter(1,2);//get the product id  //1 will be replaced by the present session user
		merchant = query.getSingleResult();
		System.out.println(merchant);
		
		//#After Discount Price #
		if(merchant.getProductPromo().equalsIgnoreCase(promo))//get the promo code from the user
		{

		 d=((merchant.getProductDiscount()*merchant.getProductPrice())/100);
		 
		}
		else
		{
		d = 0;
		}
		
		merchant.setProductDiscount(d);
		em.persist(merchant);
	
		return merchant;
	
}


	@Override
	public boolean discountUpdation(int userid)
	{
		Merchant_Product merchant=new Merchant_Product();
		
		String rs1="select m from Merchant m where m.product_Id=?1";
		TypedQuery<Merchant_Product> query = em.createQuery(rs1, Merchant_Product.class);
		query.setParameter(1,2);//get the product id  //1 will be replaced by the present session user
		merchant = query.getSingleResult();
		if(merchant.getProductId()==userid)
		{
			double d;
		/*	 d=((merchant.getProduct_Discount()*merchant.getProduct_Price())/100);*/
			 merchant.setProductPrice(merchant.getProductPrice()-merchant.getProductDiscount());
			
			return true;
		}
		else
		{
			merchant.setProductPrice(merchant.getProductPrice());
			return false;
		}
		
	}
}

