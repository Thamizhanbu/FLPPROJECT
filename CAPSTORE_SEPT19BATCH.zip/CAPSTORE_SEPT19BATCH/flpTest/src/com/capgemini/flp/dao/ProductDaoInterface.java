package com.capgemini.flp.dao;

import org.springframework.context.annotation.Configuration;

import com.capgemini.flp.dto.Merchant_Product;

@Configuration
public interface ProductDaoInterface {

	public Merchant_Product details(String promo);
	public boolean discountUpdation(int userid);

}
