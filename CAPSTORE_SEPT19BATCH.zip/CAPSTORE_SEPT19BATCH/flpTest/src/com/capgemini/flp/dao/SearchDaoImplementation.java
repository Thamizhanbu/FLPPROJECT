package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;
@Configuration
@Repository
public class SearchDaoImplementation implements SearchDaoInterface{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Customer> findCustomerByName(String customerName) {
		System.out.println("in dao");
		TypedQuery<Customer> query = entityManager.createQuery("SELECT customerdetails FROM CustomerEntity customerdetails where customerdetails.name =?1", Customer.class);
		query.setParameter(1, customerName);
		List<Customer> customerList = new ArrayList<Customer>();
		customerList = query.getResultList();
		return customerList;
	}

	@Override
	public List<Merchant> findMerchantByName(String merchantName) {
		System.out.println(merchantName);
		TypedQuery<Merchant> query = entityManager.createQuery("select merchantdetails from MerchantEntity merchantdetails where merchantdetails.name =?1", Merchant.class);
		query.setParameter(1, merchantName);
		List<Merchant> merchantList = new ArrayList<Merchant>();
		merchantList = query.getResultList();
		System.out.println("merchant fetched");
		return merchantList;
	}

	@Override
	public List<Merchant_Product> findProducts(String userData) {
		// TODO Auto-generated method stub
		TypedQuery<Merchant_Product> query = entityManager.createQuery("select productdetails from  ProductEntity productdetails where productdetails.product_Name =?1 or productdetails.product_Category=?2" , Merchant_Product.class);
		query.setParameter(1, userData);
		query.setParameter(2, userData);
		List<Merchant_Product> productList = new ArrayList<Merchant_Product>();
		productList = query.getResultList();
		return productList;
	}

	@Override
	public List<Merchant_Product> findAllProducts(String merchantId) {
		// TODO Auto-generated method stub
		TypedQuery<Merchant_Product> query = entityManager.createQuery("select productdetails from  ProductEntity productdetails where productdetails.merchant_email_Id =?1" , Merchant_Product.class);
		query.setParameter(1, merchantId);
		List<Merchant_Product> productsList = new ArrayList<Merchant_Product>();
		productsList = query.getResultList();
		return productsList;
	}


	
	

}
