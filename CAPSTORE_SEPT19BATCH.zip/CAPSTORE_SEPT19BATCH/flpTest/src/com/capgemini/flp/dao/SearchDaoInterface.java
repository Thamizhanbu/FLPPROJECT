package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;

public interface SearchDaoInterface {
	
	public List<Customer> findCustomerByName(String name);
	public List<Merchant> findMerchantByName(String merchantName);
	public List<Merchant_Product> findProducts(String userData);
	public List<Merchant_Product> findAllProducts(String merchantId);

}
