package com.capgemini.flp.exception;

public class FeedbackException extends Exception{
	private static final long serialVersionUID = 1L;
	private String status;
	
	public FeedbackException()
	{
		this.status="Unable to perform operation";
	}
	public FeedbackException(String status)
	{
		super(status);
	}
	public String getStatus() {
		return status;
	}
	@Override
	public String toString() {
		return "FeedbackException [status=" + status + "]";
	}
	

}
