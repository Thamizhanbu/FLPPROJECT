package com.capgemini.flp.exception;

public class IMerchantProfileException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public IMerchantProfileException(String message){
		super(message);
	}

}
