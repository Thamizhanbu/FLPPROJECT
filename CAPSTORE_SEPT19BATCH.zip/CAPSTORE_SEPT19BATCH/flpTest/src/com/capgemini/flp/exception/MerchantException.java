package com.capgemini.flp.exception;

public class MerchantException extends Exception{
	
	String msg;

	public MerchantException(String msg) {
		super();
		this.msg = msg;
	}

}
