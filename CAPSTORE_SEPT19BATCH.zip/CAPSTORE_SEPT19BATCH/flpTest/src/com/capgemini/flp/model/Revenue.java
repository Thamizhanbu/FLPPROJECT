package com.capgemini.flp.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;



public class Revenue {

	
	
		 @Transient
		  private double profit;
		
		@Transient
		 private double loss; 

		 @Transient
		private Double revenue;

		public double getProfit() {
			return profit;
		}

		public void setProfit(double profit) {
			this.profit = profit;
		}

		public double getLoss() {
			return loss;
		}

		public void setLoss(double loss) {
			this.loss = loss;
		}

		public Double getRevenue() {
			return revenue;
		}

		public void setRevenue(Double revenue) {
			this.revenue = revenue;
		}

		public Revenue() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Revenue(double profit, double loss, Double revenue) {
			super();
			this.profit = profit;
			this.loss = loss;
			this.revenue = revenue;
		}

		@Override
		public String toString() {
			return "Revenue [profit=" + profit + ", loss=" + loss
					+ ", revenue=" + revenue + "]";
		}

		 
		
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
