package com.capgemini.flp.service;

import java.util.List;





import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.AllException;

public interface IAdminService {

	

	public List<Customer> getAllCustomerDetails() throws AllException;

	public List<Merchant> getAllMerchantDetails() throws AllException;

	public List<Merchant_Product> getAllProductDetails()throws AllException;


	public List<Merchant_Product> getSingleProductDetails(String emailId);

}
