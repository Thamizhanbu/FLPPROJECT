package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.MerchantDAO;
@Transactional
@Service
public class ImplMerchantService implements IMerchantService {

	@Autowired
	private MerchantDAO dao; 
	
	@Override
	public void removeMerchantProducts(String emailId) {
		// TODO Auto-generated method stub
		dao.removeMerchantProducts(emailId);
		
	}
	
	/*@Autowired
	private MerchantDAO repo;
	@Autowired
	private MerchantProductDAO repop;

	@Override
	public String addMerchant(String emailId) throws MerchantException {
		String msg=null;
		Merchant_Product merchantproduct = null;
		Merchant merchant = repo.findMerchant(emailId);
		if(merchant!=null) {
		merchantproduct=repop.findMerchantProduct(emailId);
		}
		if(merchantproduct!=null) {
		msg="Merchant Added Successfully of UserName: "+emailId;
		}
		return msg;
	}

	@Override
	public String removeMerchant(String emailId) throws MerchantException {
		String msg = null;
		 Merchant merchant = repo.findMerchant(emailId);
		 repo.delete(merchant);
		 msg="Merchant Removed Successfully of UserName: "+emailId;
		return msg;
	}

	@Override
	public String inviteMerchant(String emailId) throws MerchantException {
		String msg = null;
		Merchant merchant = repo.findMerchant(emailId);
		if(merchant!=null) {
		msg="Invitation is sent to the Merchant UserName: "+emailId;
		}
		return msg;
	}

	@Override
	public List<Merchant> findAllMerchants() throws MerchantException {
		return repo.findAll();
	}*/
}
