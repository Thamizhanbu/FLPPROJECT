package com.capgemini.flp.service;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.SignUpException;

public interface IntSignUpService 
{

	public boolean addCustomer(Customer customer)throws SignUpException;
	public boolean addAdmin(Admin admin)throws SignUpException;
	public boolean addMerchant(Merchant merchant)throws SignUpException;
/*	public void Encrypt(String password,String email) throws CapstoreException;*/
	public String forget(String email) throws SignUpException;

}
