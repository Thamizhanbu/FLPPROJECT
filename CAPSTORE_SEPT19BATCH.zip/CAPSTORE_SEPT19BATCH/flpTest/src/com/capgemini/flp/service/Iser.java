package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.Wish;
import com.capgemini.flp.exception.FlpException;

public interface Iser {
	
	
	public int delete(int id,String email) throws  FlpException ;
	public List<Wish> showall(String emailId) throws FlpException ;
	public Wish add(int productId, String emailId)throws FlpException;
}
