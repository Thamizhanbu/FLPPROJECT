package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IMerchantProductDao;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.MerchantProductException;

@Transactional
@Service
public class MerchantProductServiceImpl implements IMerchantProductService {
	
	@Autowired
    IMerchantProductDao productdao;


	@Override
	public boolean addMerchantProducts(Merchant_Product product) {
		// TODO Auto-generated method stub
		return productdao.addMerchantProducts(product);
	}

	@Override
	public void removeMerchantProducts(int productId) {
		// TODO Auto-generated method stub
		productdao.removeMerchantProducts(productId);
	}

	
	
}
