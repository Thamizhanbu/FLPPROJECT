package com.capgemini.flp.service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.ProductDaoInterface;
import com.capgemini.flp.dto.Merchant_Product;

@Service
@Transactional
public class ProductServiceImplementation implements ProductServiceInterface{
	
		@Autowired
		ProductDaoInterface productdao;

		
		@Override
		public Merchant_Product details(String promo) {
			// TODO Auto-generated method stub
			return productdao.details(promo);
		

	}
		@Override
		public boolean discountUpdation(int userid) {
			// TODO Auto-generated method stub
			return productdao.discountUpdation(userid);
		}
}

	
	
	
	