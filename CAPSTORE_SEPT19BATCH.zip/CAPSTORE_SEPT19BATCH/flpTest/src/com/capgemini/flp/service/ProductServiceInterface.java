package com.capgemini.flp.service;

import com.capgemini.flp.dto.Merchant_Product;

public interface ProductServiceInterface   {
	//public double details(Merchant b);

	public Merchant_Product details(String promo);
	public boolean discountUpdation(int userid);
}
