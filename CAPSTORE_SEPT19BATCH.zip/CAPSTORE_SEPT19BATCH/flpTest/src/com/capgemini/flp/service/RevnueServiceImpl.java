package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.IRevenueDao;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.model.Revenue;
@Service
public class RevnueServiceImpl implements IRevenueService{
	
	@Autowired
	IRevenueDao dao;
	@Override
	
	public Merchant_Product findProductSold(String merchant_email_Id) {
		return dao.findProductSold(merchant_email_Id);
	}
	@Override
	public Revenue findRevenue(String email) {
		// TODO Auto-generated method stub
		return dao.findRevenue(email);
	}
	
	
}
