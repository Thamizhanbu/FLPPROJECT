package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.SearchDaoInterface;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;
@Configuration
@Transactional
@Service
public class SearchServiceImplementation implements SearchServiceInterface{

	@Autowired
	SearchDaoInterface dao;
	
	
	@Override
	public List<Customer> findCustomerByName(String name) {
		
		return dao.findCustomerByName(name);
		
	}

	@Override
	public List<Merchant> findMerchantByName(String merchantName) {
		
		return dao.findMerchantByName(merchantName);
		
	}

	@Override
	public List<Merchant_Product> findProducts(String userData) {
		
		return dao.findProducts(userData);
		
	}

	@Override
	public List<Merchant_Product> findAllProducts(String merchantId) {
		// TODO Auto-generated method stub
		return dao.findAllProducts(merchantId);
	}

	
	
	

}
