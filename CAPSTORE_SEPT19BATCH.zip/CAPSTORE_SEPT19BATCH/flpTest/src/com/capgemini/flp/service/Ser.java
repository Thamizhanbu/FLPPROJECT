package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IDao;
import com.capgemini.flp.dto.Wish;
import com.capgemini.flp.exception.FlpException;
@Service
@Transactional
public class Ser implements Iser {
	
	@Autowired
	private IDao userDAO;
	


	public  int delete(int id,String emailId) throws FlpException {
		return userDAO.delete(id,emailId);
	}

	public List<Wish> showall(String emailId) throws FlpException {
		// TODO Auto-generated method stub
		return userDAO.showall( emailId);
	}

	public Wish add(int productId, String emailId)throws FlpException {
		// TODO Auto-generated method stub
		return userDAO.add( productId,emailId);
	}



	
}
